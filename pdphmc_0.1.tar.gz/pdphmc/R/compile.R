


.compileCpp <- function(bo,
                        compiler="g++",
                        flags="-O3 -DEIGEN_NO_DEBUG  -DBOOST_DISABLE_ASSERTS  -DBOOST_PENDING_INTEGER_LOG2_HPP -DBOOST_NO_AUTO_PTR",
                        include=""){
  
  package.includes <- paste0(
  #  " -I",R.home('include'), # first two only for r-rngs
  #  " -I",system.file('include', package = "Rcpp"),
    " -I",system.file('include', package = "StanHeaders"),
    " -I",system.file('include', package = "RcppEigen"),
    " -I",system.file('include', package = "BH"),
    " -I",system.file('include', package = "RcppProgress"),
    " -I",system.file('include', package = "pdphmc"))
  
  compilerCall <- paste0(compiler," ",
                         bo@file.name.base,".cpp ",
                         " -o ",bo@file.name.base,
                         " -std=c++14 ",flags," ",
                         package.includes," ",
                         include)  
  
  cat(compilerCall)
  
  return(system(compilerCall))
  
}
