#
# methods for pdphmc-output objects
#

# uses the RStan monitor function
setGeneric(name="getMonitor",def=function(object,...) standardGeneric("getMonitor") )
setMethod("getMonitor","pdphmc-output",function(object,print=TRUE){
  object@monitor <- list(rstan::monitor(sims=object@pointSamples[2:(object@samples+1),,], warmup = object@warmup, print=print))
  return(object@monitor)
})


# uses the RStan monitor function
setGeneric(name="getIntMonitor",def=function(object,...) standardGeneric("getIntMonitor") )
setMethod("getIntMonitor","pdphmc-output",function(object,print=TRUE){
  if(print) {
    message("Warning: showing monitor for *integrated samples*",quote=FALSE)
    message("only mean and se_mean reflect the original target.",quote=FALSE)
  }
  object@intMonitor <- list(rstan::monitor(sims=object@intSamples[2:(object@samples+1),,], warmup = object@warmup, print=print))
  return(object@intMonitor)
})



setGeneric(name="trace.plot",def=function(object,...) standardGeneric("trace.plot") )
setMethod("trace.plot","pdphmc-output",function(object,which.par=NULL){
  if(is.null(which.par)){
    nms <- dimnames(object@pointSamples)[[3]]
  } else {
    nms <- which.par
  }
  nn <- length(nms)
  par(mfrow=c(nn,1))
  xlab <- ""
  for(i in 1:nn){
    if(i==nn) xlab <- "iteration #"
    ts.plot(as.vector(object@pointSamples[2:(object@samples+1),,nms[i]]),ylab=nms[i],xlab=xlab )
    if(object@chains>1){
      for(j in 0:object@chains){
        lines(j*object@samples*c(1,1),c(-1.0e300,1.0e300),col="red")
      }
    }
  }
})

setGeneric(name="mass.trace.plot",def=function(object,...) standardGeneric("mass.trace.plot") )
setMethod("mass.trace.plot","pdphmc-output",function(object,which.par=NULL){
  
  par(mfrow=c(object@chains,1))
  xlab <- ""
  main <- "inverse mass matrix diagonal max and mean"
  for(i in 1:object@chains){
    if(i==object@chains) xlab <- "trajectory #"
    ts.plot(as.vector(fit@diagnostics[[i]][,"Minv_max"]),ylab=paste0("chain # ",i),xlab=xlab,main=main )
    main <- ""
    lines(as.vector(fit@diagnostics[[i]][,"Minv_min"]),col="red" )
  }
})

setGeneric(name="trace.plot.int",def=function(object,...) standardGeneric("trace.plot.int") )
setMethod("trace.plot.int","pdphmc-output",function(object,which.par=NULL){
  if(is.null(which.par)){
    nms <- dimnames(object@intSamples)[[3]]
  } else {
    nms <- which.par
  }
  nn <- length(nms)
  par(mfrow=c(nn,1))
  xlab <- ""
  main <- "note; integrated samples"
  for(i in 1:nn){
    if(i==nn) xlab <- "iteration #"
    ts.plot(as.vector(object@intSamples[2:(object@samples+1),,nms[i]]),ylab=nms[i],xlab=xlab,main=main )
    main <- ""
    if(object@chains>1){
      for(j in 0:object@chains){
        lines(j*object@samples*c(1,1),c(-1.0e300,1.0e300),col="red")
      }
    }
  }
})



setGeneric(name="acf.plot",def=function(object,...) standardGeneric("acf.plot") )
setMethod("acf.plot","pdphmc-output",function(object,which.par=NULL){
  if(is.null(which.par)){
    nms <- dimnames(object@pointSamples)[[3]]
  } else {
    nms <- which.par
  }
  nn <- length(nms)
  par(mfrow=c(nn,object@chains))
  
  for(i in 1:nn){
    ylab <- nms[i]
    
    for(j in 1:object@chains){
      if(i==1){
        main <- paste0("chain # ",j)
      } else {
        main <- ""
      }
      acf(object@pointSamples[(object@warmup+1):(object@samples+1),j,nms[i]],ylab=ylab,
          main=main)
      ylab <- ""
    }
  }
  
})

setGeneric(name="acf.plot.int",def=function(object,...) standardGeneric("acf.plot.int") )
setMethod("acf.plot.int","pdphmc-output",function(object,which.par=NULL){
  if(is.null(which.par)){
    nms <- dimnames(object@intSamples)[[3]]
  } else {
    nms <- which.par
  }
  nn <- length(nms)
  par(mfrow=c(nn,object@chains))
  
  for(i in 1:nn){
    ylab <- nms[i]
    
    for(j in 1:object@chains){
      if(i==1){
        main <- paste0("chain # ",j)
      } else {
        main <- ""
      }
      acf(object@intSamples[(object@warmup+1):(object@samples+1),j,nms[i]],ylab=ylab,
          main=main)
      ylab <- ""
    }
  }
  
})


setGeneric(name="hist.plot",def=function(object,...) standardGeneric("hist.plot") )
setMethod("hist.plot","pdphmc-output",function(object,which.par=NULL){
  if(is.null(which.par)){
    nms <- dimnames(object@pointSamples)[[3]]
  } else {
    nms <- which.par
  }
  nn <- length(nms)
  par(mfrow=c(nn,object@chains))
  
  for(i in 1:nn){
    ylab <- nms[i]
    
    for(j in 1:object@chains){
      if(i==1){
        main <- paste0("chain # ",j)
      } else {
        main <- ""
      }
      hist(object@pointSamples[(object@warmup+1):(object@samples+1),j,nms[i]],ylab=ylab,
           main=main,probability = TRUE,xlab="")
      ylab <- ""
    }
  }
  
})


setGeneric(name="getSamples",def=function(object,...) standardGeneric("getSamples") )
setMethod("getSamples","pdphmc-output",function(object,which.par=NULL,include.warmup=FALSE){
  if(is.null(which.par)){
    nms <- dimnames(object@pointSamples)[[3]]
  } else {
    nms <- which.par
  }
  nn <- length(nms)
  dd <- object@samples
  
  if(!include.warmup){dd <- dd - object@warmup}
  
  ret <- matrix(0.0,nrow = dd*object@chains, ncol=nn)
  
  for(i in 1:nn){
    for(j in 1:object@chains){
      if(include.warmup){
        ret[((j-1)*dd+1):(j*dd),i] = object@pointSamples[2:(object@samples+1),j,nms[i]]  
      } else {
        ret[((j-1)*dd+1):(j*dd),i] = object@pointSamples[(object@warmup+2):(object@samples+1),j,nms[i]]
      }
    }
  }
  return(ret)
  
})

# 
setGeneric(name="get_CPU_time",def=function(object,...) standardGeneric("get_CPU_time") )
setMethod("get_CPU_time","pdphmc-output",function(object){
  l <- object@CPUtime
  ret <- matrix(0.0,nrow=length(l),ncol=2)
  for(i in 1:length(l)){
    t <- l[[i]]
    ret[i,] <- t[1:2]
  }
  colnames(ret) <- c("warmup","sampling")
  return(ret)
})
