


setClass(
  "build-output",
  slots = c(
    model.name = "character",
    model.cppcode = "character",
    work.folder = "character",
    build.time = "POSIXct",
    build.ID = "integer",
    file.name.base = "character",
    data.vars = "data.frame",
    par.vars = "data.frame",
    gen.vars = "data.frame",
    massMatrix = "character",
    lambda = "character",
    compile.exit.flag = "integer",
    binary.path = "character"
  )
)

setClass(
  "pdphmc-output",
  slots = c(
    modelname = "character",
    model.obj = "build-output",
    niter = "integer",
    chains = "integer",
    warmup = "integer",
    samples = "integer",
    pointSamples = "array",
    intSamples = "array",
    eventSamples = "list",
    diagnostics = "list",
    monitor = "list",
    intMonitor = "list",
    par.vec.names = "character",
    CPUtime = "list",
    fixedMi = "numeric",
    lastMiDiag = "list"
  )
)
