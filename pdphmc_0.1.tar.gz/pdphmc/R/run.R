


.json.matrix <- function(l){
  if(length(l)>0){
    for(i in 1:length(l)){
      if(is.matrix(l[[i]])){
        l[[i]] <- list(nrow=dim(l[[i]])[1],
                       vals=as.vector(l[[i]])) 
      }
    }
  }
  return(l)
}



setGeneric(
  name = "run",
  def = function(model, ...)
    standardGeneric("run")
)
setMethod("run", "build-output", function(model,
                                          samples = 2000L,
                                          Tmax = 10000.0,
                                          warmupFrac = 0.5,
                                          chains = 4L,
                                          seed = 1L,
                                          data = list(),
                                          pars = character(0),
                                          init = list(),
                                          control = list(absTol = 1.0e-3,
                                                         relTol = 1.0e-3),
                                          fixedMiDiag = list(),
                                          out.files = list(csv.prec = 8),
                                          clean = TRUE,
                                          cores = 1) {
  # verify that binary exists
  if (!file.exists(model@binary.path)) {
    stop("binary associated with model does not exist; rebuild the model")
  }
  
  
  #implement checks of inputs here
  .is.scalar <- function(arg) {
    return(length(arg) == 1)
  }
  if (!.is.scalar(samples) || samples < 1) {
    stop("samples should be scalar positive integer")
  }
  if (!.is.scalar(Tmax) || Tmax < 0.0) {
    stop("Tmax should be scalar positive real")
  }
  if (!.is.scalar(warmupFrac) || warmupFrac < 0.0 ||
      warmupFrac > 1.0) {
    stop("warmupFrac should be a scalar real between 0.0 and 1.0")
  }
  if (!.is.scalar(seed))
    stop("seed should be a scalar integer")
  
  basic.params <- list(
    samples = as.integer(samples),
    Tmax = Tmax,
    warmupFrac = warmupFrac,
    seed = as.integer(seed)
  )
  
  # use column-major storage for matrices
  data <- .json.matrix(data)
  init <- .json.matrix(init)
  
  
  
  combined <- list(
    data = data,
    pars = pars,
    init = init,
    fixedMass = fixedMiDiag,
    basic.params = basic.params,
    control = control,
    out.files = out.files,
    file.name.base = model@file.name.base
  )
  
  jf <- jsonlite::toJSON(combined, digits = 16, auto_unbox = TRUE)
  cat(jf, file = paste0(model@file.name.base, ".json"))
  
  # actual simulations
  if (cores > 1) {
    `%dopar%` <- foreach::`%dopar%`
    doParallel::registerDoParallel(cl <- parallel::makeCluster(cores))
    results_list <- foreach::foreach(chain = 1:chains) %dopar% {
      system.call <- paste0(model@binary.path, " ", chain)
      system(system.call)
    }
    parallel::stopCluster(cl)
  } else {
    results_list <- list()
    for (chain in 1:chains) {
      system.call <- paste0(model@binary.path, " ", chain)
      results_list[[chain]] <- system(system.call)
    }
  }
  
  
  ret <- new("pdphmc-output")
  ret@modelname <- model@model.name
  ret@model.obj <- model
  ret@diagnostics <- vector("list", chains)
  ret@warmup <- as.integer(warmupFrac * samples)
  ret@chains <- as.integer(chains)
  ret@samples <- as.integer(samples)
  ret@CPUtime <- vector("list", chains)
  # gather results
  for (chain in 1:chains) {
    fn.i <- paste0(model@file.name.base, "_", chain, "_point.csv")
    s.point <- as.matrix(read.csv(fn.i, check.names = FALSE))
    if (clean)
      file.remove(fn.i)
    
    fn.s <- paste0(model@file.name.base, "_", chain, "_int.csv")
    s.int <- as.matrix(read.csv(fn.s, check.names = FALSE))
    if (clean)
      file.remove(fn.s)
    
    fn.d <- paste0(model@file.name.base, "_", chain, "_diag.csv")
    s.diag <- read.csv(fn.d, check.names = FALSE)
    if (clean)
      file.remove(fn.d)
    
    fn.m <- paste0(model@file.name.base, "_", chain, "_misc.json")
    s.misc <- jsonlite::fromJSON(readLines(fn.m))
    if (clean)
      file.remove(fn.m)
    
    if (chain == 1) {
      #allocate space
      point.dims <- dim(s.point)
      ret@pointSamples <-
        array(dim = c(point.dims[1], chains, point.dims[2]))
      dimnames(ret@pointSamples) <-
        list(NULL, NULL, colnames(s.point))
      int.dims <- dim(s.int)
      ret@intSamples <- array(dim = c(int.dims[1], chains, int.dims[2]))
      dimnames(ret@intSamples) <- list(NULL, NULL, colnames(s.int))
    }
    ret@pointSamples[, chain, ] <- s.point
    ret@intSamples[, chain, ] <- s.int
    ret@diagnostics[[chain]] <- s.diag
    ret@CPUtime[[chain]] <- s.misc$CPUtime
    ret@lastMiDiag[[chain]] <- s.misc$lastMiDiag
    names(ret@lastMiDiag[[chain]]) <- s.misc$parNames
    if (chain == 1) {
      ret@par.vec.names <- s.misc$parNames
      ret@fixedMi <- s.misc$fixedMi
      names(ret@fixedMi) <- s.misc$parNames
    }
    
  }
  
  return(ret)
  
}) # setMethod
