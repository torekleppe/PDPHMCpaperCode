#ifndef __ADTARGET_HPP__
#define __ADTARGET_HPP__

/*
 * This class provides AD gradient of the original target distribution
 * 
 * 
 */

template <class _target_type_>
class ADtarget{
private:
  _target_type_ t_;
  int d_;
  int dg_;
  
  VectorXad dpar_;
  
  double ret_;
  stan::math::var dret_; 
  
public:
  // run the setup method of the target distribution and allocates some memory
  inline void setup(){
    t_.setup();
    d_ = t_.dim();
    dg_ = t_.dimGenerated();
    dpar_.resize(d_);
  }
  
  inline int dim() const {return d_;}
  inline int dimGenerated() const {return dg_;}
  
  // run the eval function with double variables, i.e. no gradient
  inline double feval(const Eigen::VectorXd &par, Eigen::VectorXd &gen){
    return(t_.eval(par,gen));
  }
  
  inline double feval(const Eigen::VectorXd &par, Eigen::Ref<Eigen::VectorXd> gen){
    return(t_.eval(par,gen));
  }
  
  // gradient eval
  double geval(const Eigen::VectorXd &par, 
               Eigen::Ref< Eigen::VectorXd > gen, 
               Eigen::Ref< Eigen::VectorXd > grad){
      dpar_ = par;
      
      try{
        dret_ = t_.eval(dpar_,gen);
      } 
      catch(...){
        stan::math::recover_memory();
        std::cout << "Bad function eval" << std::endl;
        return std::numeric_limits<double>::quiet_NaN();
      }

      ret_ = dret_.val();
      dret_.grad();
      for(int i=0;i<d_;i++) grad.coeffRef(i)=dpar_.coeff(i).adj();
      stan::math::recover_memory();
      return(ret_);
    
  }
  
  
};

#endif



